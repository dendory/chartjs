from chartjs.chartjs import chart
__version__ = "1.2"